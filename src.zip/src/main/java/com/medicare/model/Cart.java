package com.medicare.model;

import com.medicare.entity.medicine;

public class Cart {

	private medicine medi;
	//private String mediName;
	private int mediQuantity;
	private int mediPrice;
	
	public Cart() {
		// TODO Auto-generated constructor stub
	}

	public Cart( int mediQuantity, int mediPrice,medicine medi) {
		super();
		//this.mediName = mediName;
		this.mediQuantity = mediQuantity;
		this.mediPrice = mediPrice;
		this.medi = medi;
	}
	
	public Cart(medicine medi, int mediQuantity) {
		super();
		this.mediQuantity=mediQuantity;
		this.medi=medi;
	}

	public medicine getMedi() {
		return medi;
	}

	public void setMedi(medicine medi) {
		this.medi = medi;
	}

//	public String getMediName() {
//		return mediName;
//	}
//
//	public void setMediName(String mediName) {
//		this.mediName = mediName;
//	}

	public int getMediQuantity() {
		return mediQuantity;
	}

	public void setMediQuantity(int mediQuantity) {
		this.mediQuantity = mediQuantity;
	}

	public int getMediPrice() {
		return mediPrice;
	}

	public void setMediPrice(int mediPrice) {
		this.mediPrice = mediPrice;
	}
	
	
}
