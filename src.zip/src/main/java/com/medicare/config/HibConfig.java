package com.medicare.config;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

import com.medicare.entity.Booking;
import com.medicare.entity.CartItem;
import com.medicare.entity.User;
import com.medicare.entity.medicine;

public class HibConfig {
	public static SessionFactory getSessionFactory() {
		Configuration configuration = new Configuration();
		Properties properties = new Properties();
		properties.put(Environment.DRIVER, "com.mysql.cj.jdbc.Driver");
		properties.put(Environment.URL, "jdbc:mysql://localhost:3306/medicare");
		properties.put(Environment.USER, "root");
		properties.put(Environment.PASS, "roots");
		properties.put(Environment.SHOW_SQL, true);
		properties.put(Environment.FORMAT_SQL, true);
		properties.put(Environment.HBM2DDL_AUTO, "update");
		configuration.setProperties(properties);
		configuration.addAnnotatedClass(Booking.class);
		configuration.addAnnotatedClass(CartItem.class);
		configuration.addAnnotatedClass(medicine.class);
		configuration.addAnnotatedClass(User.class);
		SessionFactory factory = configuration.buildSessionFactory();
		return factory;
	}
}

