package com.medicare.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class CartItem implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cartId;
	
	@ManyToMany
    @JoinTable(
        name = "cart_item",
        joinColumns = @JoinColumn(name = "cart_id"),
        inverseJoinColumns = @JoinColumn(name = "mediId")
    )
    private List<medicine> product = new ArrayList<>();
	
	private int quantity;
	
	public CartItem() {
		// TODO Auto-generated constructor stub
	}

	public CartItem(int cartId, List<medicine> products, int quantity) {
		super();
		this.cartId = cartId;
		this.product = products;
		this.quantity = quantity;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public List<medicine> getProduct() {
		return product;
	}

	public void setProduct(List<medicine> product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public void addProduct(medicine product) {
		if (product != null) {
		this.product.add(product);
        product.getCart().add(this);}
    }

    public void removeProduct(medicine product) {
    	if (product != null) {this.product.remove(product);
        product.getCart().remove(this);}
    }

	
}

