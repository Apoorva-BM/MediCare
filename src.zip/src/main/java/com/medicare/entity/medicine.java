package com.medicare.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;


@Entity
public class medicine {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mediId;
	
	private String mediName;
	
	private int mediType;
	
	private int mediPrice;
	
	private int mediQuantity;
	
	private String imageUrl;
	
	@ManyToMany(mappedBy = "product")
    private List<CartItem> cart = new ArrayList<>();

	public medicine(int mediId, String mediName, int mediType, int mediPrice, int mediQuantity,List<CartItem> cart,String imageUrl) {
		super();
		this.mediId = mediId;
		this.mediName = mediName;
		this.mediType = mediType;
		this.mediPrice = mediPrice;
		this.mediQuantity = mediQuantity;
		this.cart = cart;
		this.imageUrl = imageUrl;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public List<CartItem> getCart() {
		return cart;
	}

	public void setCart(List<CartItem> cart) {
		this.cart = cart;
	}

	public medicine() {
		
	}

	public int getMediId() {
		return mediId;
	}

	public void setMediId(int mediId) {
		this.mediId = mediId;
	}

	public String getMediName() {
		return mediName;
	}

	public void setMediName(String mediName) {
		this.mediName = mediName;
	}

	public int getMediType() {
		return mediType;
	}

	public void setMediType(int mediType) {
		this.mediType = mediType;
	}

	public int getMediPrice() {
		return mediPrice;
	}

	public void setMediPrice(int mediPrice) {
		this.mediPrice = mediPrice;
	}

	public int getMediQuantity() {
		return mediQuantity;
	}

	public void setMediQuantity(int mediQuantity) {
		this.mediQuantity = mediQuantity;
	}

	@Override
	public String toString() {
		return "medicine [mediId=" + mediId + ", mediName=" + mediName + ", mediType=" + mediType + ", mediPrice="
				+ mediPrice + ", mediQuantity=" + mediQuantity + ", imageUrl=" + imageUrl + ", cart=" + cart + "]";
	}
	
	
	
}
