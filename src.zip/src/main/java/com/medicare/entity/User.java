package com.medicare.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userID;

	private String userName;

	private String userPwd;

	private String userEmail;
	
	@OneToMany(mappedBy ="user")
	private List<Booking> booking;
	
	public User() {
		// TODO Auto-generated constructor stub
	}

	public User(int userID, String userName, String userPwd, String userEmail, List<Booking> booking) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.userPwd = userPwd;
		this.userEmail = userEmail;
		this.booking = booking;
		
	}
	

	public void addBooking(Booking booking) {
		this.booking.add(booking);
	}
	
	public void removeBoking(Booking booking) {
		this.booking.remove(booking);
		//booking.setUser(null);
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public List<Booking> getBooking() {
		return booking;
	}

	public void setBooking(List<Booking> booking) {
		this.booking = booking;
	}
}
