package com.medicare.service;

import java.util.List;

import com.medicare.entity.medicine;

public interface MedicineService {
	 List<medicine> getProduct();
	 medicine getProductByName(String name);
}
