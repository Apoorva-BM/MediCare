package com.medicare.service;

import java.util.List;

import com.medicare.entity.CartItem;
import com.medicare.model.Cart;

public interface CartService {
	void addToCart(Cart model);
	List<CartItem> getCartItem();
}
