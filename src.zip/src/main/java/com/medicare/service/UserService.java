package com.medicare.service;

import com.medicare.entity.User;
import com.medicare.model.UserModel;

public interface UserService {
	void addUser(UserModel user);
	User getUser(String userName, String userPwd);
	User getPwdUser(String userName,String userEmail);
	void changePwd(String userName,String userPwd );
}
