package com.medicare.service.impl;

import java.util.List;

import com.medicare.dao.AddCartDao;
import com.medicare.dao.impl.AddCartDaoImpl;
import com.medicare.entity.CartItem;
import com.medicare.model.Cart;
import com.medicare.service.CartService;


public class CartServiceImpl implements CartService{
	private AddCartDao dao = new AddCartDaoImpl();
	private CartItem cart=new CartItem();
		
		@Override
		public void addToCart(Cart model) {
			cart.addProduct(model.getMedi());
			cart.setQuantity(model.getMediQuantity());
		
			dao.addToCart(cart);
		}

		@Override
		public List<CartItem> getCartItem() {
			return dao.getCartItem();
		}
}
