package com.medicare.service.impl;

import com.medicare.dao.UserDao;
import com.medicare.dao.impl.UserDaoImpl;
import com.medicare.entity.User;
import com.medicare.model.UserModel;
import com.medicare.service.UserService;

public class UserServiceImpl implements UserService {
private UserDao dao = new UserDaoImpl();
	
	@Override
	public void addUser(UserModel user) {
		User userEntity=new User();
		userEntity.setUserName(user.getUserName());
		userEntity.setUserPwd(user.getUserPwd());
		userEntity.setUserEmail(user.getUserEmail());
		dao.insertUser(userEntity);	
	}

	@Override
	public User getUser(String userName, String userPwd) {
		return dao.get(userName, userPwd);
	}

	@Override
	public User getPwdUser(String userName, String userEmail) {
		return dao.getPwd(userName,userEmail);
	}

	@Override
	public void changePwd(String userName, String userPwd) {
		dao.updatePwd(userName, userPwd);
	}
}
