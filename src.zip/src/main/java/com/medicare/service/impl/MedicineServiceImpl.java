package com.medicare.service.impl;

import java.util.List;

import com.medicare.dao.MediDao;
import com.medicare.dao.impl.MediDaoImpl;
import com.medicare.entity.medicine;
import com.medicare.service.MedicineService;


public class MedicineServiceImpl implements MedicineService {
private MediDao dao = new MediDaoImpl();
	
	@Override
	public List<medicine> getProduct() {
		
		return dao.getAllProduct();
	}

	@Override
	public medicine getProductByName(String name) {
		return dao.getProductByName(name);
	}
}
