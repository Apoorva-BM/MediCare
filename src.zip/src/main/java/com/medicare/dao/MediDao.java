package com.medicare.dao;

import java.util.List;

import com.medicare.entity.medicine;

public interface MediDao {
	List<medicine> getAllProduct();
	medicine getProductByName(String name);
}
