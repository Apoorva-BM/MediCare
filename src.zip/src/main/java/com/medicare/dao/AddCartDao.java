package com.medicare.dao;

import java.util.List;

import com.medicare.entity.CartItem;

public interface AddCartDao {

	void addToCart(CartItem item);
	List<CartItem> getCartItem();
}
