package com.medicare.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.medicare.config.HibConfig;
import com.medicare.dao.AddCartDao;
import com.medicare.entity.CartItem;

public class AddCartDaoImpl implements AddCartDao{
	@Override
	public void addToCart(CartItem item) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.save(item);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		session.close();
	}

	@Override
	public List<CartItem> getCartItem() {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		List<CartItem> item = new ArrayList<>();
		try {
			factory=HibConfig.getSessionFactory();
			session=factory.openSession();
			item = session.createQuery("FROM com.medicare.entity.CartItem p", CartItem.class)
	                .getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return item;
} }

