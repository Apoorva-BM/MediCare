package com.medicare.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.medicare.config.HibConfig;
import com.medicare.dao.MediDao;
import com.medicare.entity.medicine;

public class MediDaoImpl  implements MediDao{
	@Override
	public List<medicine> getAllProduct() {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		List<medicine> product = new ArrayList<>();
		try {
			factory=HibConfig.getSessionFactory();
			session=factory.openSession();
			product = session.createQuery("FROM com.medicare.entity.medicine p", medicine.class)
	                .getResultList();
			System.out.println("the product detail" + product);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("the product detail" + product);
		return product;
	}

	@Override
	public medicine getProductByName(String name) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		medicine product = new medicine();
		try {
			factory=HibConfig.getSessionFactory();
			session=factory.openSession();
			product = session.createQuery("FROM com.medicare.entity.medicine p where p.mediName=?1", medicine.class)
					.setParameter(1, name)
					.uniqueResult();
			System.out.println("the product detail for product by name" + product);
			System.out.println("name is " + name);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return product;
	}
}
