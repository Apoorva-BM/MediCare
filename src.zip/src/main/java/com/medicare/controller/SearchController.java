package com.medicare.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medicare.entity.medicine;
import com.medicare.service.MedicineService;
import com.medicare.service.impl.MedicineServiceImpl;
@WebServlet("/searchFor")
public class SearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MedicineService service  = new MedicineServiceImpl();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String keywords=request.getParameter("keyword");
		System.out.println(keywords);
		medicine products = service.getProductByName(keywords);
		HttpSession session=request.getSession();
		if(products!=null) {
			session.setAttribute("medicineProducts", products);
			RequestDispatcher dispatcher = request.getRequestDispatcher("search.jsp");
	        dispatcher.forward(request, response);
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("search.jsp");
			request.setAttribute("msg", "Invalid Name,Enter Again");
			rd.forward(request, response);
		}
	}

}
