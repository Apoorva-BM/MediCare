package com.medicare.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medicare.entity.medicine;
import com.medicare.service.MedicineService;
import com.medicare.service.impl.MedicineServiceImpl;
@WebServlet("/products")
public class MediController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MedicineService service= new  MedicineServiceImpl();
	   
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			HttpSession session=request.getSession();
			List<medicine> products = service.getProduct();
			//System.out.println("here1");
			if(!products.isEmpty()) {
			session.setAttribute("products", products);
			//System.out.println("here");
			RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
	        dispatcher.forward(request, response);
	        }
			else
			{
				request.setAttribute("msg", "Error");
				RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		        dispatcher.forward(request, response);
			}
			
		}



	}

