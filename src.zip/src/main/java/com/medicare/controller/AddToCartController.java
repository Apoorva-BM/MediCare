package com.medicare.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medicare.entity.CartItem;
import com.medicare.entity.medicine;
import com.medicare.model.Cart;
import com.medicare.service.CartService;
import com.medicare.service.MedicineService;
import com.medicare.service.impl.CartServiceImpl;
import com.medicare.service.impl.MedicineServiceImpl;


@WebServlet("/addToCartServlet")
public class AddToCartController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private MedicineService service = new MedicineServiceImpl();
	private CartService addCart = new CartServiceImpl();
	private Cart model = new Cart();
		
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			String productName = request.getParameter("mediName");
			String quantity =  request.getParameter("mediQuantity");
			//String price = request.getParameter("mediPrice");
			int quantities =Integer.parseInt(quantity);
			//int prices = Integer.parseInt(price);
			medicine product = service.getProductByName(productName);
			if(product!=null) {
				List<CartItem> carts=addCart.getCartItem();
				if(!carts.isEmpty()) {
					Cart model = new Cart(product, quantities);
					addCart.addToCart(model);
				}else if(!carts.contains(product)) {
					addCart.addToCart(model);
		        }
			}
			RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
			rd.forward(request, response);
		}

}
